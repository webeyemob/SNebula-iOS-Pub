//
//  TXADTikTokDislikeAction.h
//  TaurusXAdMediation_TikTok
//
//  Created by TaurusXAds on 2021/3/1.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#ifndef TXADTikTokDislikeAction_h
#define TXADTikTokDislikeAction_h


typedef NS_ENUM(NSInteger, TXADTikTokDislikeAction) {
    TXADTikTokDislikeAction_None = 0,
    TXADTikTokDislikeAction_Remove = 1
};

#endif /* TXADTikTokDislikeAction_h */
