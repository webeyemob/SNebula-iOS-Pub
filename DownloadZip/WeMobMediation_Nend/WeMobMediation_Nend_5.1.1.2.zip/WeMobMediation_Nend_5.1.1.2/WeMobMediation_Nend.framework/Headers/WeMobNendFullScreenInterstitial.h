//
//  WeMobNendFullScreenInterstitial.h
//  WeMobMediation_Nend
//
//  Created by wanghang on 2019/6/28.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobBaseInterstitial.h"
#import <NendAd/NendAd.h>

@interface WeMobNendFullScreenInterstitial : WeMobBaseInterstitial<NADFullBoardDelegate>

@end
