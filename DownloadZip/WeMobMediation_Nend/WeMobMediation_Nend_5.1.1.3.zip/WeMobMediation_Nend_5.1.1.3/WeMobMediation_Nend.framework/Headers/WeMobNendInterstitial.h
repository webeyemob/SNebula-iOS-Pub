//
//  WeMobNendInterstitial.h
//  WeMobMediation_Nend
//
//  Created by Mathew on 2019/6/27.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobCustomInterstitial.h"

@interface WeMobNendInterstitial : WeMobCustomInterstitial

@end
