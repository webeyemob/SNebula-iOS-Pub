//
//  WeMobNendBanner.h
//  WeMobMediation_Nend
//
//  Created by 王航 on 2019/6/27.
//  Copyright © 2019年 王航. All rights reserved.
//

#import "WeMobCustomBanner.h"
#import <NendAd/NendAd.h>

@interface WeMobNendBanner : WeMobCustomBanner<NADViewDelegate>

@end
