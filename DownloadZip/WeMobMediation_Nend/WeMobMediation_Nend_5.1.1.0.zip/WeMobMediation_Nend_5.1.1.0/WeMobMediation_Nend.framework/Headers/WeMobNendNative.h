//
//  WeMobNendNative.h
//  WeMobMediation_Nend
//
//  Created by 王航 on 2019/6/28.
//  Copyright © 2019年 王航. All rights reserved.
//

#import "WeMobCustomNative.h"

@interface WeMobNendNative : WeMobCustomNative

@end
