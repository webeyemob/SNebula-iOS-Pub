//
//  WeMobUnityBanner.h
//  WeMobMediation_UnityAds
//
//  Created by wanghang on 2019/6/24.
//

#import <UIKit/UIKit.h>
#import "WeMobCustomBanner.h"
#import "UnityAds/UnityAds.h"

@interface WeMobUnityBanner : WeMobCustomBanner<UnityAdsBannerDelegate>

@end
