//
//  WeMobUnityRewardedVideo.h
//  WeMobMediation_UnityAds
//

#import "WeMobCustomRewardedVideo.h"
#import "UnityAds/UnityAds.h"

@interface WeMobUnityRewardedVideo : WeMobCustomRewardedVideo<UnityMonetizationDelegate,UMONShowAdDelegate>

@end
