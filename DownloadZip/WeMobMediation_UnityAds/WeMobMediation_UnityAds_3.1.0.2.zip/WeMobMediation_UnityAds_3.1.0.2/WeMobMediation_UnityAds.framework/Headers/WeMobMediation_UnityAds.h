//
//  WeMobMediation_UnityAds.h
//  WeMobMediation_UnityAds
//
//  Created by Mathew on 2018/9/29.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_UnityAds.
FOUNDATION_EXPORT double WeMobMediation_UnityAdsVersionNumber;

//! Project version string for WeMobMediation_UnityAds.
FOUNDATION_EXPORT const unsigned char WeMobMediation_UnityAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_UnityAds/PublicHeader.h>
