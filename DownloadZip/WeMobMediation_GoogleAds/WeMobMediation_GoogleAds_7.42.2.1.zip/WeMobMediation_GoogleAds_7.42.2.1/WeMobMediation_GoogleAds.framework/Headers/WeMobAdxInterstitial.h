//
//  WeMobAdxInterstitial.h
//  WeMobMediation_GoogleAds
//
//  Created by wanghang on 2019/7/3.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobGoogleBaseInterstitial.h"

@interface WeMobAdxInterstitial : WeMobGoogleBaseInterstitial

@end
