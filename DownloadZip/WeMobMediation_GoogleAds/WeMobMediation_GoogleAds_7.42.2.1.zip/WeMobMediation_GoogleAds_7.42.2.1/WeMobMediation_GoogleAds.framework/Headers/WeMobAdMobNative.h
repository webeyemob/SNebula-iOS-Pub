//
//  WeMobAdMobNative.h
//  WeMobMediation_GoogleAds
//
//  Created by wanghang on 2019/6/21.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "WeMobGoogleBaseNative.h"

@interface WeMobAdMobNative : WeMobGoogleBaseNative

@end
