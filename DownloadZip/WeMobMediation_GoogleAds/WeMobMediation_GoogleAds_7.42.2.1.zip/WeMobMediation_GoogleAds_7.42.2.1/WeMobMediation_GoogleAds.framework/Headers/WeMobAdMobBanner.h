//
//  WeMobAdMobBanner.h
//  WeMobMediation_GoogleAds
//

#import "WeMobGoogleBaseBanner.h"

@interface WeMobAdMobBanner : WeMobGoogleBaseBanner

@end
