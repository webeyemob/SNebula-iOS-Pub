//
//  WmAdMobInterstitilAdAdapter.h
//  Mediation_AdMob
//

#import "WeMobGoogleBaseInterstitial.h"

@interface WeMobAdMobInterstitial : WeMobGoogleBaseInterstitial

@end
