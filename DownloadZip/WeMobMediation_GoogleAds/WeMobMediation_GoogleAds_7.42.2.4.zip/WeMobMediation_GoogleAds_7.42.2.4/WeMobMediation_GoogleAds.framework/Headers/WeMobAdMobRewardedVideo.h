//
//  WeMobAdMobRewardedVideo.h
//  Mediation_AdMob
//

#import "WeMobGoogleBaseRewardedVideo.h"

@interface WeMobAdMobRewardedVideo : WeMobGoogleBaseRewardedVideo

@end
