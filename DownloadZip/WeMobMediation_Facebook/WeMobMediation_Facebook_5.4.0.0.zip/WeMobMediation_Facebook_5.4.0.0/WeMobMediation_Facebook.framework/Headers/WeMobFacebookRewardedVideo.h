//
//  WeMobFacebookRewardedVideo.h
//  WeMobMediation_Facebook
//

#import "WeMobCustomRewardedVideo.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>

@interface WeMobFacebookRewardedVideo : WeMobCustomRewardedVideo<FBRewardedVideoAdDelegate>

@end
