//
//  WeMobFacebookBanner.h
//  WeMobMediation_Facebook
//

#import "WeMobCustomBanner.h"
#import <FBAudienceNetwork/FBAudienceNetwork.h>

@interface WeMobFacebookBanner : WeMobCustomBanner<FBAdViewDelegate>

@end
