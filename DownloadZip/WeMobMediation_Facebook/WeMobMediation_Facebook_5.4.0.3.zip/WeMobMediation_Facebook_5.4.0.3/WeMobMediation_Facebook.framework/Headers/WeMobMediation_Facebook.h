//
//  WeMobMediation_Facebook.h
//  WeMobMediation_Facebook
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_Facebook.
FOUNDATION_EXPORT double WeMobMediation_FacebookVersionNumber;

//! Project version string for WeMobMediation_Facebook.
FOUNDATION_EXPORT const unsigned char WeMobMediation_FacebookVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_Facebook/PublicHeader.h>
