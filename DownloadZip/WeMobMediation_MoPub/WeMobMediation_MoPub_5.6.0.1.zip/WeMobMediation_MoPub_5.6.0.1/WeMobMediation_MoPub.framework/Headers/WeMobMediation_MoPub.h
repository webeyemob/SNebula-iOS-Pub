//
//  WeMobMediation_MoPub.h
//  WeMobMediation_MoPub
//
//  Created by wanghang on 2019/6/25.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_MoPub.
FOUNDATION_EXPORT double WeMobMediation_MoPubVersionNumber;

//! Project version string for WeMobMediation_MoPub.
FOUNDATION_EXPORT const unsigned char WeMobMediation_MoPubVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_MoPub/PublicHeader.h>
