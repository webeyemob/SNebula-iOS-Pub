//
//  WeMobMoPubInterstitial.h
//  WeMobMediation_MoPub
//
//  Created by wanghang on 2019/6/26.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import <MoPubSDKFramework/MoPub.h>
#import "WeMobCustomInterstitial.h"

@interface WeMobMoPubInterstitial : WeMobCustomInterstitial<MPInterstitialAdControllerDelegate>

@end
