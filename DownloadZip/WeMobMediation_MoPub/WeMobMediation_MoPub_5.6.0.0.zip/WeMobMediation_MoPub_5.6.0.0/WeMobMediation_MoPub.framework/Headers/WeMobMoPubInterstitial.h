//
//  WeMobMoPubInterstitial.h
//  WeMobMediation_MoPub
//
//  Created by 王航 on 2019/6/26.
//  Copyright © 2019年 王航. All rights reserved.
//

#import <MoPubSDKFramework/MoPub.h>
#import "WeMobCustomInterstitial.h"

@interface WeMobMoPubInterstitial : WeMobCustomInterstitial<MPInterstitialAdControllerDelegate>

@end
