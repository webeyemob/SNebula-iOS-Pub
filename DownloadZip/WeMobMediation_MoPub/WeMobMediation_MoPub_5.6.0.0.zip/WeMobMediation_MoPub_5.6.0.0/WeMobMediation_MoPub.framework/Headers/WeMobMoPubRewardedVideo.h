//
//  WeMobMoPubRewardedVideo.h
//  WeMobMediation_MoPub
//
//  Created by 王航 on 2019/6/26.
//  Copyright © 2019年 王航. All rights reserved.
//

#import <MoPubSDKFramework/MoPub.h>
#import "WeMobCustomRewardedVideo.h"

@interface WeMobMoPubRewardedVideo : WeMobCustomRewardedVideo<MPRewardedVideoDelegate>

@end
