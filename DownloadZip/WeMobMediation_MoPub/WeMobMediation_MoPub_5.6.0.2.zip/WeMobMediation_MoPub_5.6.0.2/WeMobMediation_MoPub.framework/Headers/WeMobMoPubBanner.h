//
//  WeMobMoPubBanner.h
//  WeMobMediation_MoPub
//
//  Created by Mathew on 2019/6/25.
//

#import <MoPubSDKFramework/MoPub.h>
#import "WeMobCustomBanner.h"

@interface WeMobMoPubBanner : WeMobCustomBanner<MPAdViewDelegate>

@end
