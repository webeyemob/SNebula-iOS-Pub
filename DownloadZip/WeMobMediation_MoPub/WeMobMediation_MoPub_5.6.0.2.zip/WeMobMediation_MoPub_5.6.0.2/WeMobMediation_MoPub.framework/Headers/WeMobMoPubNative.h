//
//  WeMobMoPubNative.h
//  WeMobMediation_MoPub
//
//  Created by Mathew on 2019/6/26.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import <MoPubSDKFramework/MoPub.h>
#import "WeMobCustomNative.h"

@interface WeMobMoPubNative : WeMobCustomNative<MPNativeAdDelegate>

@end
