//
//  WeMobWeDspNative.h
//  WeMobSdk
//
//  Created by tangzheng on 2019/6/27.
//  Copyright © 2019 wanghang All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WeMobCustomNative.h"

NS_ASSUME_NONNULL_BEGIN

@interface WeMobWeDspNative:  WeMobCustomNative

@end

NS_ASSUME_NONNULL_END
