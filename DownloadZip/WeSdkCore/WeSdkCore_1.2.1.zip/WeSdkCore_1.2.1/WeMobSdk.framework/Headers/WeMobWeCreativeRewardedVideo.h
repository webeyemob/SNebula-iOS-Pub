//
//  WeMobWeCreativeRewardedVideo.h
//  Mediation_WeCreative
//

#import "WeMobCustomRewardedVideo.h"


@interface WeMobWeCreativeRewardedVideo : WeMobCustomRewardedVideo

@end
