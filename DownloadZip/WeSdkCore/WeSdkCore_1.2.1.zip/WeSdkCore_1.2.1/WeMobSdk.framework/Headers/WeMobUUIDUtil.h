//
//  WeMobUUIDUtil.h

//
//  Created by Mathew on 2019/6/14.
//

#import <Foundation/Foundation.h>

@interface WeMobUUIDUtil : NSObject

+(NSString *)getUUID;

@end
