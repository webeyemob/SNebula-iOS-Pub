//
//  WeMobWeCreativeNative.h
//  WeMobSdk
//
//  Created by 汤正 on 2019/6/27.
//  Copyright © 2019 王航. All rights reserved.
//

#import "WeMobCustomNative.h"

NS_ASSUME_NONNULL_BEGIN

@interface WeMobWeCreativeNative : WeMobCustomNative

@end

NS_ASSUME_NONNULL_END
