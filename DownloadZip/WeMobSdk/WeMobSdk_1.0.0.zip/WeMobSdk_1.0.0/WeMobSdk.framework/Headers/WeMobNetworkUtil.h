//
//  WeMobNetworkUtil.h
//  WeMobSdk
//
//  Created by 王航 on 2019/6/16.
//

@interface WeMobNetworkUtil : NSObject

+(BOOL)isNetworkConnected;

@end
