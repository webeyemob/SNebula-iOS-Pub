//
//  WeMobNetworkUtil.h
//  WeMobSdk
//
//  Created by Mathew on 2019/6/16.
//

@interface WeMobNetworkUtil : NSObject

+(BOOL)isNetworkConnected;

@end
