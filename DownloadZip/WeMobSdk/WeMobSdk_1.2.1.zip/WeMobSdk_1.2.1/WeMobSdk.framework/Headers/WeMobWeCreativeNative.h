//
//  WeMobWeCreativeNative.h
//  WeMobSdk
//
//  Created by tamefox on 2019/6/27.
//  Copyright © 2019 wanghang All rights reserved.
//

#import "WeMobCustomNative.h"

NS_ASSUME_NONNULL_BEGIN

@interface WeMobWeCreativeNative : WeMobCustomNative

@end

NS_ASSUME_NONNULL_END
