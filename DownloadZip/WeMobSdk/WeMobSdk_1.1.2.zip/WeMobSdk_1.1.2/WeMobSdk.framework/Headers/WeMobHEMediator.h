//
//  WeMobHEMediator.h
//  WeMobSdk
//
//  Created by 王航 on 2019/7/12.
//  Copyright © 2019年 WeMobSdk. All rights reserved.
//

#import "WeMobDefaultMediator.h"

@interface WeMobHEMediator : WeMobDefaultMediator

@end
