//
//  WeMobTimeUtil.h
//  WeMobSdk
//
//  Created by wanghang on 2019/6/17.
//

@interface WeMobTimeUtil : NSObject

+(long long)getDateTimeMilliSeconds;

@end
