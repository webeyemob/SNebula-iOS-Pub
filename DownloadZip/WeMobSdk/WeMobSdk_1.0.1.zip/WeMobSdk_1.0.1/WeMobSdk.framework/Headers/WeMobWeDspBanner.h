//
//  WeMobAdMobBanner.h
//  WeMobMediation_AdMob
//

#import "WeMobCustomBanner.h"


@interface WeMobWeDspBanner : WeMobCustomBanner

@end
