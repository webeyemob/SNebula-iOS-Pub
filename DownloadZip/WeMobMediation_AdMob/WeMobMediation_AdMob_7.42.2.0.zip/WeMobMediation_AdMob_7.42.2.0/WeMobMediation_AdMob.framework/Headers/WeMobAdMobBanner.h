//
//  WeMobAdMobBanner.h
//  WeMobMediation_AdMob
//

#import "WeMobCustomBanner.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface WeMobAdMobBanner : WeMobCustomBanner<GADBannerViewDelegate>

@end
