//
//  WmAdMobInterstitilAdAdapter.h
//  Mediation_AdMob
//

#import "WeMobCustomInterstitial.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface WeMobAdMobInterstitial : WeMobCustomInterstitial<GADInterstitialDelegate>

@end
