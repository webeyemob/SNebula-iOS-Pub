//
//  WeMobMediation_AdMob.h
//  WeMobMediation_AdMob
//
//  Created by 王航 on 2018/9/13.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_AdMob.
FOUNDATION_EXPORT double WeMobMediation_AdMobVersionNumber;

//! Project version string for WeMobMediation_AdMob.
FOUNDATION_EXPORT const unsigned char WeMobMediation_AdMobVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_AdMob/PublicHeader.h>
