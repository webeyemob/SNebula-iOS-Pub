//
//  WeMobAdMobRewardedVideo.h
//  Mediation_AdMob
//

#import "WeMobCustomRewardedVideo.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface WeMobAdMobRewardedVideo : WeMobCustomRewardedVideo<GADRewardBasedVideoAdDelegate>

@end
