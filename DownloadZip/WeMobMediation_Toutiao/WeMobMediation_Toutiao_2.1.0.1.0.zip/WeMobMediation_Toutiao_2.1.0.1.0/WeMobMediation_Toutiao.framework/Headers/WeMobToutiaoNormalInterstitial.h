//
//  WeMobToutiaoNormalInterstitial.h
//  WeMobMediation_Toutiao
//
//  Created by 王航 on 2019/7/4.
//  Copyright © 2019年 wesdk_wanghang. All rights reserved.
//

#import "WeMobBaseInterstitial.h"

@interface WeMobToutiaoNormalInterstitial : WeMobBaseInterstitial

@end
