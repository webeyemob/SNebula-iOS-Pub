//
//  WeMobToutiaoBannerNative.h
//  WeMobMediation_Toutiao
//
//  Created by wanghang on 2019/7/4.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobBaseNative.h"

@interface WeMobToutiaoBannerNative : WeMobBaseNative

@end
