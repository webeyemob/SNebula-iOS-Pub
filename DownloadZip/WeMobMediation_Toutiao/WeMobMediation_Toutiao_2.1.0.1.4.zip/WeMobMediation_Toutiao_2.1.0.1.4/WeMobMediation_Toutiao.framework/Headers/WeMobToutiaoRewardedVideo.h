//
//  WeMobToutiaoRewardedVideo.h
//  WeMobMediation_Toutiao
//
//  Created by Mathew on 2019/7/4.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobCustomRewardedVideo.h"

@interface WeMobToutiaoRewardedVideo : WeMobCustomRewardedVideo

@end
