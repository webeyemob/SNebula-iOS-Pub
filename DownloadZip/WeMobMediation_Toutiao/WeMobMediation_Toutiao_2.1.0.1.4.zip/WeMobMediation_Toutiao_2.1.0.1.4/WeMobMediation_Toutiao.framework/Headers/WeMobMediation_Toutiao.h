//
//  WeMobMediation_Toutiao.h
//  WeMobMediation_Toutiao
//
//  Created by Mathew on 2019/7/3.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_Toutiao.
FOUNDATION_EXPORT double WeMobMediation_ToutiaoVersionNumber;

//! Project version string for WeMobMediation_Toutiao.
FOUNDATION_EXPORT const unsigned char WeMobMediation_ToutiaoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_Toutiao/PublicHeader.h>


