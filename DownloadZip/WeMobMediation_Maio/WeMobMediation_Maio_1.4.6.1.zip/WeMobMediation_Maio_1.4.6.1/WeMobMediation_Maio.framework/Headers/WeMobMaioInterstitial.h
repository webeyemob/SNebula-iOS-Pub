//
//  WeMobMaioInterstitial.h
//  WeMobMediation_Maio
//
//  Created by wanghang on 2019/6/27.
//  Copyright © 2019年 WeSdk. All rights reserved.
//

#import "WeMobCustomInterstitial.h"
#import <Maio/Maio.h>

@interface WeMobMaioInterstitial : WeMobCustomInterstitial<MaioDelegate>

@end
