//
//  WeMobMaioInterstitial.h
//  WeMobMediation_Maio
//
//  Created by 王航 on 2019/6/27.
//  Copyright © 2019年 王航. All rights reserved.
//

#import "WeMobCustomInterstitial.h"
#import <Maio/Maio.h>

@interface WeMobMaioInterstitial : WeMobCustomInterstitial<MaioDelegate>

@end
