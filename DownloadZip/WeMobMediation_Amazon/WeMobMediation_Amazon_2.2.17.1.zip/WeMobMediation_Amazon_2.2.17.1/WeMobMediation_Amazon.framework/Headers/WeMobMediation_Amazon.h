//
//  WeMobMediation_Amazon.h
//  WeMobMediation_Amazon
//
//  Created by Mathew on 2019/6/24.
//

#import <UIKit/UIKit.h>

//! Project version number for WeMobMediation_Amazon.
FOUNDATION_EXPORT double WeMobMediation_AmazonVersionNumber;

//! Project version string for WeMobMediation_Amazon.
FOUNDATION_EXPORT const unsigned char WeMobMediation_AmazonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeMobMediation_Amazon/PublicHeader.h>
