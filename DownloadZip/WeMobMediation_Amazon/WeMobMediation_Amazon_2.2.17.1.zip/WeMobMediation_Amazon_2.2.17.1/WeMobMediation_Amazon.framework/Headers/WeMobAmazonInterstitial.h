//
//  WeMobAmazonInterstitial.h
//  WeMobMediation_Amazon
//
//  Created by Mathew on 2019/6/24.
//

#import <UIKit/UIKit.h>
#import "WeMobCustomInterstitial.h"
#import <AmazonAd/AmazonAd.h>

@interface WeMobAmazonInterstitial : WeMobCustomInterstitial<AmazonAdInterstitialDelegate>

@end
