//
//  WeMobAmazonBanner.h
//  WeMobMediation_Amazon
//
//  Created by 王航 on 2019/6/24.
//

#import "WeMobCustomBanner.h"
#import <AmazonAd/AmazonAd.h>

@interface WeMobAmazonBanner : WeMobCustomBanner<AmazonAdViewDelegate>

@end
