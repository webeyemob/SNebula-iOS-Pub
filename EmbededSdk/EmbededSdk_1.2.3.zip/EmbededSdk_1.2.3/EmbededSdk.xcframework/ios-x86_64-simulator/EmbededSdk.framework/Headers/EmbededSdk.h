//
//  EmbededSdk.h
//  EmbededSdk
//
//  Created by Embed on 2021/1/5.
//  Copyright © 2021 Embed. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for EmbededSdk.
FOUNDATION_EXPORT double EmbededSdkVersionNumber;

//! Project version string for EmbededSdk.
FOUNDATION_EXPORT const unsigned char EmbededSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EmbededSdk/PublicHeader.h>

#import <EmbededSdk/Embeded.h>
#import <EmbededSdk/EmbedTypes.h>
#import <EmbededSdk/EmbedObjectCache.h>
