//
//  TaurusXAdMediation_Mobrain.h
//  TaurusXAdMediation_Mobrain
//
//  Created by TaurusXAds on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_Mobrain.
FOUNDATION_EXPORT double SNebulaAdMediation_MobrainVersionNumber;

//! Project version string for TaurusXAdMediation_Mobrain.
FOUNDATION_EXPORT const unsigned char SNebulaAdMediation_MobrainVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Mobrain/PublicHeader.h>


#import <SNebulaAdMediation_Mobrain/TXADMobrainAdMode.h>
