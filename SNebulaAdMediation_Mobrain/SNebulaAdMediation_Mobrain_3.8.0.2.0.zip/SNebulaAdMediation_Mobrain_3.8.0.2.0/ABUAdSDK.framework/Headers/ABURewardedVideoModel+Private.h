//
//  ABURewardedVideoModel+Private.h
//  Ads-Mediation-CN
//
//  Created by CHAORS on 2021/11/26.
//

#import "ABURewardedVideoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABURewardedVideoModel (Private)

- (NSString *)toString;

@end

NS_ASSUME_NONNULL_END
