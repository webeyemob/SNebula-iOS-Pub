//
//  ABUDictionary.h
//  Ads-Mediation-CN
//
//  Created by bytedance on 2022/8/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUDictionary : NSDictionary

@end

NS_ASSUME_NONNULL_END
