//
//  TXADNetworkConfig.h
//  TXADSdk
//
//  Created by TaurusXAds on 2019/10/8.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TXADNetworkConfig : NSObject

-(void)log:(NSString *)message;

@end
