//
//  TaurusXAdMediation_KuaiShou.h
//  TaurusXAdMediation_KuaiShou
//
//  Created by TaurusXAds on 2019/11/22.
//  Copyright © 2019 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_KuaiShou.
FOUNDATION_EXPORT double SNebulaAdMediation_KuaiShouVersionNumber;

//! Project version string for TaurusXAdMediation_KuaiShou.
FOUNDATION_EXPORT const unsigned char SNebulaAdMediation_KuaiShouVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_KuaiShou/PublicHeader.h>

#import <SNebulaAdMediation_KuaiShou/TXADKuaiShouAdMode.h>
#import <SNebulaAdMediation_KuaiShou/TXADKuaiShouInterstitialConfig.h>
#import <SNebulaAdMediation_KuaiShou/TXADKuaiShouRewardedVideoConfig.h>
