//
//  ABUAdKsAdapter.h
//  Pods
//
//  Created by bytedance on 2021/12/7.
//

#ifndef ABUAdKsAdapter_h
#define ABUAdKsAdapter_h


#endif /* ABUAdKsAdapter_h */
