//
//  TXADGDTRewardedVideoConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2020/1/2.
//  Copyright © 2020年 TaurusXAds. All rights reserved.
//

#import <SNebulaAds/SNebulaAds.h>

@interface TXADGDTRewardedVideoConfig : TXADNetworkConfig

@end
