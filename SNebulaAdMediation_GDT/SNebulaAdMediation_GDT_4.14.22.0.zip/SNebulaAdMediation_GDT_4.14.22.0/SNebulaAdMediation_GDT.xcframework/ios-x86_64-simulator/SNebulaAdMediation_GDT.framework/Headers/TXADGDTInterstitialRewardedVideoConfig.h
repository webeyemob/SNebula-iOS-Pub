//
//  TXADGDTInterstitialRewardedVideoConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2021/8/9.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <SNebulaAds/SNebulaAds.h>
@class GDTVideoConfig;

NS_ASSUME_NONNULL_BEGIN

@interface TXADGDTInterstitialRewardedVideoConfig : TXADNetworkConfig

@property (nonatomic, strong) GDTVideoConfig *videoConfig;
@property (nonatomic) NSInteger minVideoDuration;
@property (nonatomic) NSInteger maxVideoDuration;
@end

NS_ASSUME_NONNULL_END
